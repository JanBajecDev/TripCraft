// Intake.jsx — single-screen, card-based trip intake.

function Stepper({ value, min, max, onChange, suffix }) {
  return (
    <div className="stepper">
      <button type="button" className="step-btn" disabled={value <= min} onClick={() => onChange(Math.max(min, value - 1))} aria-label="Decrease">
        <span className="material-symbols-outlined">remove</span>
      </button>
      <span className="step-val">{value}<span className="step-suffix">{suffix}</span></span>
      <button type="button" className="step-btn" disabled={value >= max} onClick={() => onChange(Math.min(max, value + 1))} aria-label="Increase">
        <span className="material-symbols-outlined">add</span>
      </button>
    </div>
  );
}

function FieldCard({ icon, label, children, full, className }) {
  return (
    <div className={`field-card${full ? ' full' : ''}${className ? ' ' + className : ''}`}>
      <div className="field-head">
        <span className="material-symbols-outlined">{icon}</span>
        <span className="field-label">{label}</span>
      </div>
      <div className="field-body">{children}</div>
    </div>
  );
}

function Intake({ state, set, onSubmit }) {
  const dest = DESTINATIONS.find(d => d.id === state.destination) || DESTINATIONS[0];

  return (
    <div className="intake-scroll">
      <div className="intake">
        <header className="intake-hero">
          <div className="eyebrow">Plan with Wayfare</div>
          <h1 className="display">Tell us the shape of the trip.<br/>We’ll plan the rest — then talk it through.</h1>
          <p className="lede">Pick a few essentials below. Wayfare drafts a full itinerary — flights, a place to stay, things to do — and you fine-tune everything by chatting with it.</p>
        </header>

        <div className="field-grid">
          <FieldCard icon="my_location" label="Flying from">
            <div className="seg-select">
              {ORIGINS.slice(0, 3).map(o => (
                <button key={o} type="button" className={`seg${state.origin === o ? ' on' : ''}`} onClick={() => set({ origin: o })}>{o}</button>
              ))}
              <div className="select-wrap">
                <select value={state.origin} onChange={e => set({ origin: e.target.value })}>
                  {ORIGINS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
                <span className="material-symbols-outlined">expand_more</span>
              </div>
            </div>
          </FieldCard>

          <FieldCard icon="travel_explore" label="Where to">
            <div className="dest-row">
              {DESTINATIONS.map(d => (
                <button key={d.id} type="button" className={`dest-chip${state.destination === d.id ? ' on' : ''}`} onClick={() => set({ destination: d.id })}>
                  <span className="dest-city">{d.city}</span>
                  <span className="dest-code">{d.code}</span>
                </button>
              ))}
            </div>
            <p className="field-note"><span className="material-symbols-outlined">info</span>{dest.note} · {dest.country}</p>
          </FieldCard>

          <FieldCard icon="event" label="Dates">
            <div className="seg-group">
              <button type="button" className={`seg${state.dateMode === 'exact' ? ' on' : ''}`} onClick={() => set({ dateMode: 'exact' })}>Exact dates</button>
              <button type="button" className={`seg${state.dateMode === 'flexible' ? ' on' : ''}`} onClick={() => set({ dateMode: 'flexible' })}>Flexible — best value</button>
            </div>
            {state.dateMode === 'exact'
              ? <div className="date-value"><span className="material-symbols-outlined">calendar_month</span>{state.dateExact}</div>
              : <div className="date-value"><span className="material-symbols-outlined">savings</span>We’ll find the cheapest stretch in {state.dateMonth}</div>}
          </FieldCard>

          <FieldCard icon="schedule" label="Length of stay">
            <Stepper value={state.days} min={2} max={14} suffix=" days" onChange={v => set({ days: v })} />
            <p className="field-note">{state.days - 1} nights away</p>
          </FieldCard>

          <FieldCard icon="group" label="Travellers">
            <Stepper value={state.travellers} min={1} max={8} suffix={state.travellers === 1 ? ' person' : ' people'} onChange={v => set({ travellers: v })} />
          </FieldCard>

          <FieldCard icon="payments" label="Total budget">
            <div className="budget-value">£{state.budget.toLocaleString()}</div>
            <input type="range" min="800" max="6000" step="100" value={state.budget} onChange={e => set({ budget: +e.target.value })} className="budget-range" style={{ '--pct': ((state.budget - 800) / (6000 - 800) * 100) + '%' }} />
            <div className="budget-scale"><span>£800</span><span>£6,000</span></div>
          </FieldCard>

          <FieldCard icon="interests" label="Interests" full>
            <div className="interest-row">
              {INTERESTS.map(it => {
                const on = state.interests.includes(it.id);
                return (
                  <button key={it.id} type="button" className={`interest-chip${on ? ' on' : ''}`}
                    onClick={() => set({ interests: on ? state.interests.filter(x => x !== it.id) : [...state.interests, it.id] })}>
                    <span className="material-symbols-outlined">{it.icon}</span>{it.label}
                    {on && <span className="material-symbols-outlined check">check</span>}
                  </button>
                );
              })}
            </div>
          </FieldCard>
        </div>

        <div className="intake-cta">
          <button type="button" className="btn-primary lg" onClick={onSubmit} disabled={state.interests.length === 0}>
            Plan my trip
            <span className="material-symbols-outlined">arrow_forward</span>
          </button>
          <p className="cta-note">Free to plan. You only book what you like.</p>
        </div>
      </div>
    </div>
  );
}

window.Intake = Intake;
